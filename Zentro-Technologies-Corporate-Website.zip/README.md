# Zentro Technologies corporate website
Premium responsive corporate website built with React + Vite.

## Pages
Home, About, Services, Industries, Our Work, Careers, Contact.

## Portfolio
- GlowV — skincare technology client project.
- MediTrust AI — healthcare AI product initiative (description is intentionally high-level until approved details are supplied).

## Run
1. Install Node.js 18+.
2. Extract the ZIP and open this folder in VS Code.
3. Run `npm install`.
4. Run `npm run dev`.
5. Run `npm run build` for production.

## Before publishing
- Replace placeholder email addresses with verified company inboxes.
- Confirm the legal company name, address, phone, social links and brand assets.
- Confirm whether MediTrust AI is a client project, owned product or internal initiative and approve its public description.
- Add approved project screenshots, client permissions, outcomes and case-study details.
- Contact form currently opens the visitor's email application; connect a backend or form service for stored submissions.
